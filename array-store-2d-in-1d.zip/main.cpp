#include <iostream>
using namespace std;

int main ()
{
  int i, j, k=0, a[100][100], n, m, sum, b[100];

  cout << "Enter the value for n for array a[i] : ";
  cin >> n;

  cout << "Enter the value for m for array a[j] : ";
  cin >> m;

  cout << "Enter the elements for array a[i][j] : ";

  for (i = 0; i < n; i++)
    {
      for (j = 0; j < m; j++)
	{
	  cin >> a[i][j];
	  
	}
	
    } 
    
   for (i = 0; i < n; i++)
    {
      for (j = 0; j < m; j++)
	{
	    b[k] = a[i][j];
	    k++;
	}
	
    }
    
    for( k=0; k < m*n; k++ )
    {
       cout << b[k] << " , ";
       
    }
    
    return 0;
    
}
    