#include <iostream>
using namespace std;

int main ()
{
  int n, i, a;

  a = 0;

  cout << "Enter the number n : ";
  cin >> n;

  for (i = 2; i <= n/2; i++)
    {
      if (n % i == 0)
      {
	     a = a + 1;
	     break;
      }  

    }
    
  if (a > 0)
    cout << "Given num is not prime";

  else
    cout << "Given num is prime";

  return 0;

}
