#include<iostream>
using namespace std;

int main()
{
     int i, n, A[i], B[i], C[i];
     
cout << "Enter the value for n :";
cin >> n;

cout << "Enter elements for A[i] : ";

for ( i = 0; i < n; i++ )
{
    cin >> A[i];
    
} 

cout << "Enter elements for B[j] : ";

for ( i = 0; i < n; i++ )
{
    cin >> B[i];
    
} 

 cout << "final array C[i] is : ";

for ( i = 0; i < n; i++ )
{  
    if ( A[i] % 2 == 0)
    {C[i] = A[i];
    cout << C[i] << " ";}
} 

for ( i = 0; i < n; i++ )
{  
    if ( B[i] % 2 == 0)
    {C[i] = B[i];
    cout << C[i] << " ";}
}

for ( i = 0; i < n; i++ )
{  
    if ( A[i] % 2 != 0)
    {C[i] = A[i];
    cout << C[i] << " ";}
} 

for ( i = 0; i < n; i++ )
{  
    if ( B[i] % 2 != 0)
    {C[i] = B[i];
    cout << C[i] << " ";}
} 



  
return 0;
}
    



