#include <iostream>
using namespace std;

int main()
{
    int i, j, n, var = 1;

cout << "enter the value for n: ";
cin >> n;

for( i = 0; i <= n; i++ )
{   cout << " \n ";

    for (j = 0; j <= n - i - 2; j++)
	{
	  cout << " " ;

	}
	
    for ( j = 0; j <= i; j ++ )
    {  
        if ( j == 0)
        var == 1;
    
        else
        var = var* (i - j + 1)/j;

    
       cout << " " << var;
    }   
}    
    
    
    

    return 0;
}
