#include<iostream>
#include<math.h>
using namespace std;

int main ()
{
  int n, a = 1, i, x;
  int Sum = 0;
  cout << "Enter the value for n : ";
  cin >> n;

  cout << "Enter the value for x : ";
  cin >> x;

  for (i = 2; i <= n; i = i + 2)
    {
      Sum = Sum + pow (x, i) * a;

      a = a * -1;

    }
  cout << Sum;

  return 0;

}
