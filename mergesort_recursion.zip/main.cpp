#include <iostream>
using namespace std;

 void merge( int a[], int s, int e, int mid)
    { 
        int i = e-s+1;
        int temp [i];
        int index = 0;
        int left = s;
        int right = mid + 1;
        
        while( left <= mid &&  right<=e)
        {
            if(a[left] < a[right])
            {
                temp[index] = a[left];
                index ++;
                left++;
            }
            
            else
            {
                temp[index] = a[right];
                index ++;
                right++;
            }
        }
        
        while(left <= mid)
        {
             temp[index] = a[left];
                index ++;
                left++;
            
        }
        
         while(right <= e)
        {
            temp[index] = a[right];
                index ++;
                right++;
            
        }
        
         index = 0;
        
        while(s<=e)
        {
            a[s] = temp[index];
            index++;
            s++;
        }
    }

void division( int a[], int s, int e)
{
    if( s == e)
    { 
        return;
    }
    int mid = s + (e-s)/2;
    
     division(a,s,mid);
     division(a,mid+1,e);
     merge(a,s,e,mid);
    
}

int main()
{
    int a[7] = {6,4,7,2,9,8,3};
    int start = 0;
    int end = 6;
    cout<<"Original array -> ";
    
    for(int i = start; i<=end; i++)
    {
        if(i < end)
        cout<< a[i]<< ", ";
        
        else
        cout<< a[i];
    }

    division(a,start, end);
    
    cout<<"\nSorted array -> ";
    
    for(int i = start; i<=end; i++)
    {
        if(i < end)
        cout<< a[i]<< ", ";
        
        else
        cout<< a[i];
    }

    return 0;
}
