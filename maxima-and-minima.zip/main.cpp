#include <iostream>
using namespace std;

int main ()
{
  int x, a, i, max, min;

  cout << " Enter the number of integers : ";
  cin >> x;

  cout << " Enter 1 num : ";
  cin >> a;

  max = a;
  min = a;

  for (i = 2; i <= x; i++)
    {
      cout << " Enter " << i << " num : ";
      cin >> a;

      if (a > max)
	max = a;

      if (a < min)
	min = a;
    }

  cout << "Max no. is :  " << max;
  cout << "\nMin no. is " << min;

  return 0;
}
