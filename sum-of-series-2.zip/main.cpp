#include <iostream>
#include<math.h>
using namespace std;

int main()
{ 
    int n, x, i, a = 1;
    double sum;
     
     sum = 0.00;
     
cout<<" Enter value for n : ";
cin>>n;

cout<<" Enter value for x : ";
cin >>x;
 
 for( i = 2; i <= n; i++ )
  {
     sum = sum + a*( i/pow( x, i));
         
         a = a*-1;

  } 
  
  cout<< " = " << sum ;
      
    return 0;
}
