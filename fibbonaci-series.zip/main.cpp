#include <iostream>
using namespace std;

int main ()
{
  int n, i, first_term = 0, second_term = 1, third_term;

  cout << " Enter value for n : ";
  cin >> n;
   
  if ( n >= 1)
  cout<<0<<" , ";
  
  if ( n >= 2)
  cout<<1<<", ";
   
  for ( i = 1; i <= n; i++)
   {   
       third_term = first_term + second_term;       
       first_term = second_term;
       second_term = third_term;
        
        cout << third_term<<" , ";
   }
  return 0;

}

