#include <iostream>
using namespace std;

int main()
{
    int n, a, i;
    
    a= 0;

cout<<" Enter the value for n : ";
cin>>n; 

for( i = 1; i <= n; i++ )
{ 
    a = a + i;
     cout<< i << " + " ;
    
    if( i == n)
     cout<<"\n"<<" = " << a;
     
} 
return 0;
}


