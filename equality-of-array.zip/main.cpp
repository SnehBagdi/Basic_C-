#include<iostream>
using namespace std;

int main()
{
     int i,  n, A[i], B[i], a = 0;
     
cout << "Enter the value for n :";
cin >> n;

cout << "Enter elements for A[i] : ";

for ( i = 0; i < n; i++ )
{
    cin >> A[i];
    
} 

cout << "Enter elements for B[j] : ";

for ( i = 0; i < n; i++ )
{
    cin >> B[i];
    
} 

for ( i = 0; i < n; i++ )
{
           if ( A[i] == B[i] )
           a = a + 1;
           else
             break;
} 

     if ( a == n )
     cout << " Equal ";
     
     else
     cout << " Not equal ";
  
return 0;
}

