#include <iostream>
using namespace std;

int main ()
{
  int n, i, j, min, pos, a[100], temp;

  cout << " Enter the value for n : ";
  cin >> n;

  cout << " Enter the values for array a[i] : ";

  for (i = 0; i < n; i++)
    {
      cin >> a[i];

    } 
    
for( j = 0; j < n; j++ )
{
    min = a[j];
    pos = j;

  for (i = j+1; i < n; i++)
    {

      if (a[i] < min)
      {	
          min = a[i];
          pos = i;
      }    

    } 
       a[pos]=a[j];
       a[j]  = min;
}

 for (i = 0; i < n; i++)
    {
      cout << a[i] << " , ";

    } 
    
     
     
  return 0;
}
