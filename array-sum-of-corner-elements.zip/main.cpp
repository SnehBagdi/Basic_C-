#include <iostream>
using namespace std;

int
main ()
{
  int i, j, a[100][100], n, m, sum = 0;

  cout << "Enter the value for n for array a[i] : ";
  cin >> n;

  cout << "Enter the value for m for array a[j] : ";
  cin >> m;

  cout << "Enter the elements for array a[i][j] : ";

  for (i = 0; i < n; i++)
    {
      for (j = 0; j < m; j++)
	{
	  cin >> a[i][j];
	}
    }


  for (i = 0; i < n; i++)
    {
      for (j = 0; j < m; j++)
	{
	  if (i == 0 || j == 0 || i == n - 1 || j == m - 1)
	    {
	      sum = sum + a[i][j];
	    }

	}

    }


  cout << " Required sum is : " << sum;

  return 0;
}
