#include <iostream>
using namespace std;

int main ()
{
  int n, r;

  cout << "Enter the number n : ";
  cin >> n;

  while (n > 0)
    {
      r = n % 10;
      cout << r;
      n = n / 10;
    }

  cout << " = is the reverse of given num ";

  return 0;
}
