#include <iostream>
using namespace std;

int main ()
{
  int i, j, a[100][100], n, m, sum;

  cout << "Enter the value for n for array a[i] : ";
  cin >> n;

  cout << "Enter the value for m for array a[j] : ";
  cin >> m;

  cout << "Enter the elements for array a[i][j] : ";

  for (i = 0; i < n; i++)
    {
      for (j = 0; j < m; j++)
	{
	  cin >> a[i][j];
	}
	
    } 
    
  for (j = 0; j < m; j++)
    {  
        sum = 0;
        
      for (i = 0; i < n; i++)
      {
          sum = sum + a[i][j];
      } 
      
      cout << " Sum of row " << j+1 << " is : "<< sum<<endl;
      
    }
    
return 0;
}
    
