#include <iostream>
using namespace std;

int main()
{  
    int i, n, fact=1;
    cout<<"Enter the number 'n' whose fact we have to find: ";
    cin>>n;
    
    for( i=1; i<=n; i++){
        
        fact = i*fact;
    
    }
    
            cout<<"factorial of "<< n <<" is: "<<fact<<endl;
}
