#include <iostream>
#include <math.h>
using namespace std;

int main()
{ 
    int n, x, i, a=1;
    double sum =0; 

cout<<"Enter the value for n : ";
cin>>n;

cout<< "Enter the value for x : ";
cin>>x;

for( i = 1; i <= n; i++)
{ 
    a = a*i;
    sum = sum + (pow( x, i )/a);
    
} 
       
    cout<< sum ;

    return 0;
}
