#include <iostream>
using namespace std;

int main ()
{
  int i, j, n;

  cout << "enter the value for n : ";
  cin >> n;

  for (i = n; i > 0; i--)
    {
      cout << " \n ";

      for (j = 1; j <= i; j++)
	{
	  cout << j;

	}

      for (j = n; j > 0; j--)
	{
	  if (j > i)
	    cout << " " << " ";

	  else if (j != n)
	    cout << j;

	}

    }

  return 0;
}
