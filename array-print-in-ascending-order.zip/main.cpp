#include<iostream>
using namespace std;

int main ()
{
  int i, n, p, a[200], x;

  cout << "Enter the value for n : ";
  cin >> n;

  cout << "Enter the num p : ";
  cin >> p;

  cout << "Enter the value of A[i] : ";

  for (i = 0; i < n; i++)
    {
      cin >> a[i];

    }

  for (i = 0; i < n; i++)
    {
      if (a[i] > p)
	{
	  n++;

	  for (x = n; x > i; x--)
	    {
	      a[x] = a[x - 1];

	    }
	  a[i] = p;
	  break;
	}
    }

  for (i = 0; i < n; i++)
    {
      cout << a[i] << " , ";

    }

  return 0;
}
