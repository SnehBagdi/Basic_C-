#include <iostream>

using namespace std;

int main()
{
    int i, n, s;
    cout<<"Enter the number'n' whose table has to be printed : ";
    cin>>n;
    
do
{
    s = i*n;
    cout<<i<<"*"<<n<<"="<<s<<endl;
    i++;
    
} while(i<=10);

    return 0;
}
