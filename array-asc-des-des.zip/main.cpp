#include <iostream>
using namespace std;

int main()
{
    int i, j, k, a[100], b[100], c[200], n, m;
    
cout << "Enter the value for n : ";
cin >> n;

cout << "Enter the value for m : ";
cin >> m;

cout << "Enter the elements of a[i] : ";

for( i=0; i<n; i++ )
{
    cin >> a[i];
}

cout << "Enter the elements of b[j] : ";

for( j=0; j<m; j++ )
{
    cin >> b[j];
} 

 i=0; j=m-1; k=0;
 
while( i<n && j>=0)
{ 
    if( a[i] > b[j] )
 {
    c[k] = a[i];
    k++; i++;
    
 }
 
    else
 {
    c[k] = b[j];
    k++; j--;
 }
 
}

while( i<n )
{
    c[k++] = a[i++];
}

while( j>=0 )
{
    c[k++] = b[j--];
}

for( k=0; k<n+m; k++ )
{
    cout << c[k]<<"  ";
}
    return 0;
}