#include<iostream>
using namespace std;

int main()
{
    
   int m,n;
   
   cout<<"enter first number m: ";
   cin>>m;
   
   cout<<"enter second number n: ";
   cin>>n;
   
while(m!=n)
{
    if(m>n)
    {
        m = m - n;
    
    }
    
    if(n>m)
    {
        n = n-m;
    
    }
}

cout<<"greatest common divisor is : "<<m;
return 0;

}

 
