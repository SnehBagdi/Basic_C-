#include<iostream>
using namespace std;

int main()
{

    int i, j, a[100], n, temp;

    cout << "Enter the value for n :";
    cin>>n;

    cout << "Enter elements of array a[i] : ";
    for (int i = 0; i < n; i++)
    {
        cin >> a[i];
    }

    for ( i = 0; i < n; i++)
    {
        for ( j = i+1 ; j < n; j++ ) 
        {
            if (a[i] > a[j])
            {
                temp = a[i];
                a[i] = a[j];
                a[j] = temp;
            }
        }
    }
    cout << "Sorted array is :";
    
    for ( i = 0; i < n; i++) 
    {
        cout << a[i] << " ";
    }

    return 0;
}