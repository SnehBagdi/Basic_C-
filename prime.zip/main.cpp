#include <iostream>
using namespace std;

int main ()
{
  int i, j, n, m;
  int x;

  cout << "Enter the smaller number n : ";
  cin >> n;

  cout << "Enter the bigger number m : ";
  cin >> m;

  for (i = n; i <= m; i++)
    {
      x = 0;

      for (j = 2; j <= i / 2; j++)
	{

	  if (i % j == 0)

	    {
	      x = x + 1;
	      break;
	    }


	}

      if (x == 0)
	cout << i << " ";
    }

  return 0;
}
