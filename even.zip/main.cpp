#include <iostream>
using namespace std;

intmain ()
{
  int n, i;

  cout << "enter the num: ";
  cin >> n;

  for (i = 1; i <= n; i++)
    {
      if (i % 2 == 0)
	cout << i << " ";
    }

  return 0;
}
