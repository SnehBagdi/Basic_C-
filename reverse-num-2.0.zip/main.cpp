#include<iostream>
#include<math.h>
using namespace std;

int main ()
{
  int n, r,a;
  int number = 0;

  cout << "enter the num n : ";
  cin >> n;

  while (n > 0)
    {
      r = n % 10;
      number = number + r;
      number = number*10;
      n = n / 10;
    }
    
  cout << "reversed number is : " << number/10;
  return 0;
}
