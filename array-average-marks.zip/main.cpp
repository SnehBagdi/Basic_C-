#include <iostream>
using namespace std;

int main ()
{
  int i, j, A[i], n, a = 0;
  float sum = 0;

  cout << "Enter the value for n : ";
  cin >> n;

  for (i = 0; i <= n; i++)
    {
      cout << "enter marks : ";
      cin >> A[i];

      if (A[i] >= 33)
	{
	  sum = sum + A[i];
	  a = a + 1;
	}

    }
  sum = sum / a;
  cout << " average passing marks = " << sum;
  return 0;

}
