#include <iostream>
using namespace std;

int main()
{ 
    int n, r, a;
    int number = 0;
    
cout<<"Enter the number n : ";
cin>>n;
    
    a = n;
    
while( n > 0)
{ 
    r = n % 10;
    number = number*10 + r;
    
    n = n/10;
}
   
   if ( number == a)
  cout<<"Given no. is a palindrome ";
   else
  cout<<"Given no. is not a palindrome ";
  
 return 0;
}



