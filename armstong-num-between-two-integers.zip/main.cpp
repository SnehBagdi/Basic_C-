#include <iostream>
#include<math.h>
using namespace std;

int
main ()
{
  int i, n, m, a, b;
  int x, r, sum;

  cout << "Enter the smaller number n : ";
  cin >> n;

  cout << "Enter the bigger number m : ";
  cin >> m;

  for (i = n; i <= m; i++)
    {
      a = i;
      b = i;
      x = 0;
      sum = 0;

      while (b > 0)
	{
	  b = b / 10;
	  x = x + 1;

	}

      while (a > 0)
	{
	  r = a % 10;
	  sum = sum + pow (r, x);
	  a = a / 10;

	}

      if (sum == i)
	cout << sum << " ";


    }


  return 0;
}

