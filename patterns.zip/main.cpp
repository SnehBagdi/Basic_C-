#include <iostream>
using namespace std;

int main ()
{
  int i, j, n;

  cout << "Enter the value for n : ";
  cin >> n;

  for (i = 1; i <= n; i++)
    {
      cout << " \n ";

      for (j = 1; j <= i; j++)
	{
	  if (i == j && i != n)
	    cout << i;

	  if (j == 1 && j != i)
	    cout << 1;

	  if (j < i && i != n)
	    cout << " " << " ";
	}

      for (j = 2; j <= n; j++)
	{
	  if (i == n)
	    cout << " " << j;

	}

    }

  return 0;

}

