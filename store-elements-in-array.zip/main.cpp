#include <iostream>
using namespace std;

int main()
{
    int  i, n, a[i];

cout << " enter the value for n : ";
cin >> n;

for ( i = 0; i++; i < n+1)
 { 
     cout << " enter value for array : ";
     cin >> a[i];
 }
 
for ( i = 0; i++; i < n+1)
{ 
     cout << " elements of array are : ";
     cout << a[i];
} 
   

    return 0;
}
