#include <iostream>
using namespace std;

int main ()
{

  int n, a, i, y;
      a = 0;
  cout << "Enter the num n : ";
  cin >> n;

  for (i = 1; i <= n; i++)
    {
    if (i % 2 == 0)
	   { cout << i << " x " << i << " + ";
    
       y = (i*i) + a;  
       
       a = (i*i); 
	       
	   }
    
    if (i == n)
	    cout << " = " << y;
        
    }

  return 0;
}


