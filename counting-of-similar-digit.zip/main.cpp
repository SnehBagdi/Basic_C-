#include <iostream>
using namespace std;

int main()
{
  int n, r, a;
  int sum = 0;

  cout << "Enter the number n : ";
  cin >> n;

  cout << "Enter the digit a : ";
  cin >> a;

  while (n > 0)
    {
      r = n % 10;
      n = n / 10;

      if (a == r)
	sum = sum + 1;
    }

  cout << sum;

  return 0;
}
