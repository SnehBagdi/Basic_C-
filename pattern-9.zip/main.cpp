#include<iostream>
using namespace std;

int main ()
{
  int i, j, n, a;

  cout << "Enter the value for n : ";
  cin >> n;

  for (i = 1; i <= n; i++)
    {
      cout << " \n ";

     for (j = 1; j <= n; j++)
    	{     
        if ( j <= i)
        cout << j;

        else if ( j > i)
        cout << " ";
  
     }
       


	   for (j = n-1; j > 0; j--)
	{     

        if ( j <= i )
        cout << j;

        else if ( j > i)
        cout << " ";
        
        

  } 
    
	  }

  return 0;
}