#include <iostream>
using namespace std;

int main ()
{
  int i, j, n;
  
   

  cout << "Enter valur for n : ";
  cin >> n;

  for (i = 1; i <= n; i++)
    {
      cout << " \n ";

      for (j = n; j > 0; j--)
	{
	  if (j > i)
	    cout << " ";

	  else
	    cout << i - (j - 1);
	} 
	
	 for ( j = i; j > 1; j --)
	 { 
	     cout << j - 1;

     } 
    
  
}

  return 0;
}