#include <iostream>
using namespace std;

struct student
{   
    int code;
    char name[30];
    float marks[10];
    int department_no;//1.IT 2.COMP 3.EXTC 4.DATA SCIENCE
};

int main() 
{
    struct student S1;
    int i ;
    
    cout << "Enter code: ";
    cin >> S1.code;
    cout << "Enter name: ";
    cin >> S1.name;
    cout << "Enter department_no : ";
    cin >> S1.department_no;
    cout << "marks : ";
    for ( i = 0; i < 4; i++ )
    { 
        cin >> S1.marks[i];
    
    }
   
    cout << "Code: " << S1.code << endl;
    cout << "Name: " << S1.name << endl;
    cout << "Department_no : " << S1.department_no << endl;
    cout << "Marks : " << endl;
    for ( i = 0; i < 4; i++ )
    { 
        cout << S1.marks[i] << " ";
    
    }
        
    return 0;
}