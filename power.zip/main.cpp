#include <iostream>
using namespace std;

int main ()
{
  int n, i, x, a;
  a = 1;
  cout << "enter the num: ";
  cin >> n;

  cout << "enter the num x to be printed" << " " << n << " times : ";
  cin >> x;
  for (i = 1; i <= n; i++)
    {

      a = x * a;
      if (i == n)
	cout << a;
    }

  return 0;
}

