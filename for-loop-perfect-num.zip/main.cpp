#include <iostream>
using namespace std;

int main()
{
   int n, sum;
   
  cout<<"Enter the number 'n' to check if it's a perfect number or not: ";
  cin>>n;
  
  for(int i=1; i<=n; i++){
      
      if(n%i == 0)
      {
         sum = sum+i;
      }
      
      else
      continue;
  }
  
  if( sum == 2*n )
  {
      cout<<n<<" is a perfect number and sum of divisors are : "<<sum;
  }
  
  else
  {
      cout<<n<<" is a not perfect number";
  }
  
    return 0;
}