#include <iostream>
using namespace std;

int main()
{
    int i, j, n ;
    
cout << "Enter the value for n : ";
cin >> n;

for( i = 1; i <= n ; i++ )
{     
    cout << " \n ";
    
    for ( j = 1; j <= n ; j++ )
    {   
        if( j == i && i != 1 && i != n )
        cout << "*";
        
        if( i == 1 )
        cout << "*";
           
        else
        cout << " ";
        
    } 
    
    for ( j = 1; j <= n ; j++ )
    {   
        if( j == i && i != n && i != 1)
        cout << "*";
        
        if( i == n )
        cout << "*";
           
        else
        cout << " ";
        
    } 
    
}

    return 0;
}



