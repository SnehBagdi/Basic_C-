#include <iostream>
using namespace std;

int main ()
{
  int i, j, a[100][100], n, m, sum = 0;

  cout << "Enter the value for n for array a[i] and a[j] : ";
  cin >> n;

  cout << "Enter the elements for array a[i][j] : ";

  for (i = 0; i < n; i++)
    {
      for (j = 0; j < n; j++)
	{
	  cin >> a[i][j];
	}

    }

  for (i = 0; i < n; i++)
    {
      for (j = 0; j < n; j++)
	{
	  if (j >= i)
	    sum = sum + a[i][j];

	}

    }

  cout << "Required sum is : " << sum;
}
