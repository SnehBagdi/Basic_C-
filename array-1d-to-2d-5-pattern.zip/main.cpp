#include <iostream>
using namespace std;

int main ()
{
  int i, j, k, n, m, a[100], b[100][100];

  cout << "Enter the value for n : ";
  cin >> n;

  cout << "Enter value for 1D array a[i] : ";

  for (i = 0; i < n; i++)
    {
      cin >> a[i];
    }

  cout << "Required 2D array is : ";


  for (i = 0; i < n; i++)
    {
      cout << "\n";

      for (k = 0; k < n; k++)
       {
           if( k == i || k ==  n-1-i )
           b[i][k] = a[i];
           
       }
    }
    
     for (i = 0; i < n; i++)
    {
      cout << "\n";

      for (k = 0; k < n; k++)
       {  
           cout << b[i][k];
       }
    }
    
    return 0;
}