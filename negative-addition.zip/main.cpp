#include <iostream>
using namespace std;

int main ()
{
  int n, a, x, i, y, c;
  a = -1;
  x = -1;
  c = 0;
  cout << "enter n : ";
  cin >> n;

  for (i = 1; i <= n; i++)
    {

      if (i % 2 != 0)
	{   
	     a = a * x;
	  cout << (a * i) << " +  ";
	     
	      y = a*i;
	      
	      c = y + c;
	}
	  if (i == n)

	    cout << " = " << c;

    }
  return 0;

}


