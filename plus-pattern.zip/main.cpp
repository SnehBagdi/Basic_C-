#include <iostream>
using namespace std;

int
main ()
{
  int i, n, j;

  cout << "enter value for n : ";
  cin >> n;

  for (i = 1; i <= 2 * n + 1; i++)
    {
      cout << " \n ";

      for (j = 1; j <= 2 * n + 1; j++)
	{
	  if (j == n + 1 && i != n + 1)
	    cout << "+";

	  else if (i != n + 1)
	    cout << " ";

	  if (i == n + 1)
	    cout << "+";
	}


    }

  return 0;
}
