#include <iostream>
using namespace std;

intmain ()
{
  int n, i, a;
  a = 1;
  cout << "enter the num: ";
  cin >> n;

  for (i = 1; i <= n; i++)
    {
      a = a * i;
      if (i == n)
	cout << a;

    }

  return 0;
}
