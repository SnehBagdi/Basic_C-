#include <iostream>
using namespace std;

int main()
{
    int i, a[10] = {6,8,13,17,20,22,25,28,30,35}, key;
    
cout<<"enter value of key element :";
cin>>key;

int l = 5;

 if( key > a[l])
 {
      for( i = l; i<=9; i++)
      {
          
          if( key == a[i])
          {
              cout<<"key is at position "<<i<<" in array";
              break;
              
          }
          
          if(i==9 && key!=a[i])
              {
                  cout<<"key not found";
              }
          
          
          
      }
      
 }
 
 
 if( key < a[l])
 {
      for( i = l; i>=0; i--)
      {
          
          if( key == a[i])
          {
              cout<<"key is at position "<<i<<" in array";
              break;
              

          }
          
          if(i==0 && key!=a[i])
              {
                  cout<<"key not found";
              }
          
          
      }
      
      
 }
 

    return 0;
}