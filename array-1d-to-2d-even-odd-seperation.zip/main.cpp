#include <iostream>
using namespace std;

int
main ()
{
  int i, k, n, m, a[100], b[100][100];

  cout << "Enter the value for n : ";
  cin >> n;

  cout << "Enter value for 1D array a[i] : ";

  for (i = 0; i < n; i++)
    {
      cin >> a[i];
    }

  int j = 0;
  k = 0;

  for (i = 0; i < n; i++)
    {
      if (a[i] % 2 == 0)
	{
	  b[j][k] = a[i];
	  k++;
	}

    }

  j = 1;
  k = n - 1;

  for (i = n - 1; i >= 0; i--)
    {
      if (a[i] % 2 != 0)
	{
	  b[j][k] = a[i];
	  k--;
	}

    }

  cout << "Required 2D array is : ";

  for (j = 0; j < 2; j++)
    {
      cout << " \n ";

      for (k = 0; k < n; k++)
	{
	  cout << b[j][k];

	}

    }

  return 0;
}
