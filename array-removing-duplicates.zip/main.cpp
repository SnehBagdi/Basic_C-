#include<iostream>
using namespace std;

int main ()
{
  int i, n, a[200], j, k;

  cout << "Enter the value for n : ";
  cin >> n;

  cout << "Enter the value of A[i] : ";

  for (i = 0; i < n; i++)
    {
      cin >> a[i];

    }

  for (i = 0; i < n; i++)
    {
      for (j = i + 1; j < n;)
	{
	   if (a[i] == a[j])

	  {
	      for (k = j; k < n; k++)
	      {
		     a[k] = a[k + 1];
	      }
	      
	      n--;
	  }  
	  
	  else
	  j++;
	}
    }

  for (i = 0; i < n; i++)
    {
      cout << a[i] << " , ";

    }

  return 0;
}


