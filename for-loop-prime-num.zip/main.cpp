#include <iostream>
using namespace std;

int main()
{
    int i, n, count;
    
 cout<<"enter the number 'n' : ";
 cin>>n;
 
 for(i=1; i <= n; i++)
 {
     
     if( n % i == 0)
     {
         count = count+1;
     }
 }
   
   if(count==2)
   {
       cout<<"number "<<n<<" is a prime number";
     
   } 
   
   else
   {
       cout<<n<<" is not a prime  number";
   }
    
}
