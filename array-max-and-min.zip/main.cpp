#include <iostream>
using namespace std;

int main()
{
    int i, j, size, a[100], max, min;
    
cout << "Enter the size: ";
cin >> size;

cout << "Enter the elements of array : ";

for( i=0; i<size; i++ )
{
    cin >> a[i];
} 

max = a[0];
min = a[0];

for( i=0; i<size; i++ )
{
    if( max < a[i])
    {
        max = a[i];
        
    }
    
} 


for( i=0; i<size; i++ )
{
    if( min > a[i])
    {
        min = a[i];
        
    }
    
} 

cout << " max and min numbers are  " << max << " , " << min << " respectively ";

return 0;
}


