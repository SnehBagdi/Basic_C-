#include <iostream>
using namespace std;

int main()
{
    int n, i, j, a[100], temp;
    
cout << "Enter the value for n : ";
cin >> n;

cout << "Enter the value elements for array a[i] : ";

for( i=0; i<n; i++ )
{
    cin >> a[i];
} 

for( i=0; i<n; i++ )
{ 
    for( j=0; j<n-i; j++ )
  {
 
        if( a[j]>a[j+1] )
        { 
            temp = a[j];
            a[j] = a[j+1];
            a[j+1] = temp;
        } 
        
    }
}

for( i=0; i<n; i++ )
{
    cout<< a[i] << " , ";
} 

return 0;
}
