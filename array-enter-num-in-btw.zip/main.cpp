#include<iostream>
using namespace std;

int
main ()
{
  int i, n, p, x, a[200];

  cout << "Enter the value for n : ";
  cin >> n;

  cout << "Enter the position p and num x : ";
  cin >> p >> x;

  cout << "Enter the value of A[i] : ";

  for (i = 0; i < n; i++)
    {
      cin >> a[i];

    }

  for (i = n; i >= p; i--)
    {

      a[i + 1] = a[i];
    }

  a[p] = x;
  n++;

  for (i = 0; i < n; i++)
    {
      cout << a[i] << " , ";

    }



  return 0;
}
