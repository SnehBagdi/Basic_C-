#include <iostream>
using namespace std;

int main()
{
   int i;
   int a[] = {3, 4, 5, 6, 7 };
 
cout << " Elements of given array are: \n ";

for( i=0; i < 5; i++ )
{
    cout << a[i] << " \n ";
}

return 0;
}