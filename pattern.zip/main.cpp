#include<iostream>
using namespace std;

int main ()
{
  int i, j, n, a = 0;

  cout << " enter the value for n : ";
  cin >> n;

  for (i = 1; i <= n; i++)
    {
      cout << "\n ";

      for (j = 1; j <= n - i; j++)
	{
	  cout << " ";

	}
      for (j = 1; j <= 2 * i - 1; j++)
	{
	  if ((j == 1 || j == 2 * i - 1) && (i != n))
	    cout << i;

	  else if (i != n)
	    cout << " ";

	  if (i == n)
	    cout << n;
	}

    }

  return 0;
}
