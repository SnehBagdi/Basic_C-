#include <iostream>
using namespace std;

int main()
{
    int x, y, amount;

 cout<<"enter number of coins of 5 availabe (x) :";
 cin>>x;
 
 cout<<"enter number of coins of 1 availabe (y) :";
 cin>>y;
 
 cout<<"enter total amount :";
 cin>>amount;
 
 if(amount >= 5*x)
 {
     amount = amount-5*x;
      if(amount == 0)
      {
          cout<<x<<" coins of 5 needed only";
      }
      else if(y>amount)
      {
          y = amount;
          cout<<x<<","<<y<<" no of coins of 5 and 1 needed respectively";
      }
      else
      {
          cout<<"-1";
      }
     
 }
 
 else if (amount >= 1*y)
 {
    if(amount >= x)
    {
         x = amount / 5;
    amount = amount - 5*x;
    if(amount == 0)
      {
          cout<<x<<"no of coins of 5 needed only";
      }
    else if(y>amount)
      {
          y = amount;
          cout<<x<<","<<y<<" no of coins of 5 and 1 needed respectively";
      }
    else
      {
          cout<<"-1";
      }
    }
    
    else
    {
        if(amount == y)
        cout<<y<<" coins of 1 needed only";
    }
}

 else if(amount >0)
 {
    y = amount;
    cout<<y<<"coins of 1 needed only";
      
 }
 
 else
 {
     cout<<"-1";
     
 }

    return 0;
}


